package com.savage.plugins.profile.guis;

import com.savage.plugins.profile.Profile;
import com.savage.plugins.profile.guis.menuutilities.MenuSystem;
import com.savage.plugins.profile.guis.menuutilities.PlayerMenuUtility;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.model.user.User;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.*;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.awt.*;
import java.io.File;
import java.util.ArrayList;
import java.util.UUID;

import static com.savage.plugins.profile.guis.ProfileGUI.taskID1;

public class InfoGUI extends MenuSystem {

    public InfoGUI(PlayerMenuUtility menuUtility) {
        super(menuUtility);
    }

    FileConfiguration config = Profile.getPlugin().getConfig();

    @Override
    public String getMenuName() {
        return config.getString("profile-name");
    }

    @Override
    public int getSlots() {
        return 45;
    }

    @Override
    public void handleMenu(InventoryClickEvent e) {
    }


    @Override
    public void setMenuItems() {
        UUID uuid = menuUtility.getPlayerToMod().getUniqueId();
        String targetname = menuUtility.getPlayerToMod().getName();
        Server server = Bukkit.getServer();
        Player onlineTarget = Bukkit.getPlayer(uuid);


        //PlayerHead
        ItemStack playerHead = new ItemStack(Material.PLAYER_HEAD, 1);
        SkullMeta skull = (SkullMeta) playerHead.getItemMeta();
        skull.setOwningPlayer(server.getOfflinePlayer(uuid));
        playerHead.setItemMeta(skull);
        ItemMeta PMeta = playerHead.getItemMeta();
        PMeta.setDisplayName(ChatColor.WHITE + targetname);
        playerHead.setItemMeta(PMeta);
        inv.setItem(4, playerHead);

        //Fly
        ItemStack Elytra = new ItemStack(Material.ELYTRA, 1);
        ItemMeta flymeta = Elytra.getItemMeta();
        flymeta.setDisplayName(ChatColor.LIGHT_PURPLE + "Fly:" );
        ArrayList<String> Flylore = new ArrayList<>();
        Flylore.add("Has Fly: " + onlineTarget.getAllowFlight());
        Elytra.setItemMeta(flymeta);
        flymeta.setLore(Flylore);
        inv.setItem(22,Elytra);

        //Balance
        Economy eco = Profile.getEconomy();
        ItemStack money = new ItemStack(Material.GOLD_INGOT, 1);
        ItemMeta moneymeta = money.getItemMeta();
        moneymeta.setDisplayName(ChatColor.GOLD + targetname + "'s Balence");
        ArrayList<String> moneylore = new ArrayList<>();
        moneylore.add(ChatColor.GOLD + eco.format(eco.getBalance(targetname)));
        money.setItemMeta(moneymeta);
        moneymeta.setLore(moneylore);
        inv.setItem(29,money);

        //Rank
        User user = LuckPermsProvider.get().getPlayerAdapter(Player.class).getUser(onlineTarget);
        String userrank = user.getPrimaryGroup();
        ItemStack rank = new ItemStack(Material.PAPER,1);
        ItemMeta rankmeta = rank.getItemMeta();
        rankmeta.setDisplayName(ChatColor.AQUA + "Rank:");
        ArrayList<String> ranklore = new ArrayList<>();
        ranklore.add(targetname + "'s Rank" + userrank);
        rank.setItemMeta(rankmeta);
        rankmeta.setLore(ranklore);
        inv.setItem(33, rank);

        //Fillers
        ItemStack fill = new ItemStack(Material.LIGHT_BLUE_STAINED_GLASS_PANE, 1);
        ItemMeta fillmeta = fill.getItemMeta();
        fillmeta.setDisplayName(" ");
        fill.setItemMeta(fillmeta);


    }


}
